<?php
namespace raklib\protocol;


class DATA_PACKET_9 extends DataPacket{
    public static $ID = 0x89;
}