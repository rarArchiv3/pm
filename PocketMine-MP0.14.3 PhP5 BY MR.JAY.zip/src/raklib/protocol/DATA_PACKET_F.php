<?php
namespace raklib\protocol;


class DATA_PACKET_F extends DataPacket{
    public static $ID = 0x8F;
}