<?php
namespace raklib\protocol;


class DATA_PACKET_C extends DataPacket{
    public static $ID = 0x8C;
}