<?php
namespace raklib\protocol;


class DATA_PACKET_A extends DataPacket{
    public static $ID = 0x8A;
}