<?php
namespace pocketmine\block;

interface RedstoneTransmitter{
	public function isRedstoneTransmitter();
}
