<?php
namespace pocketmine\block;


class FenceGateAcacia extends FenceGate{

	protected $id = self::FENCE_GATE_ACACIA;

	public function getName(){
		return "Acacia Fence Gate";
	}
}