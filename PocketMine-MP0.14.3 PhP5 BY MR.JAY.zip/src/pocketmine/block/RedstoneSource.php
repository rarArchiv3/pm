<?php
namespace pocketmine\block;

interface RedstoneSource{
	public function isRedstoneSource();
}