<?php
namespace pocketmine\block;

interface RedstoneSwitch{
	public function isRedstoneSwitch();
}