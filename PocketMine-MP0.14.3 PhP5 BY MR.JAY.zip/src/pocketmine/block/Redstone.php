<?php
namespace pocketmine\block;

interface Redstone{
	public function isRedstone();
}