<?php
/**
 * All the different object classes used in populators
 */
namespace pocketmine\level\generator\object;


abstract class Object{

}