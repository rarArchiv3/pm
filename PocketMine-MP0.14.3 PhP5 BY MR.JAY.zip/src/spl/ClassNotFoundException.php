<?php
class ClassNotFoundException extends LogicException{

}