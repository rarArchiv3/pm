<?php
class ClassCastException extends InvalidArgumentException{

}