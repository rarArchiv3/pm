<?php
class UndefinedConstantException extends InvalidStateException{

}