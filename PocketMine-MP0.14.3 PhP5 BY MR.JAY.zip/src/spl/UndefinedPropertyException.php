<?php
class UndefinedPropertyException extends LogicException{

}