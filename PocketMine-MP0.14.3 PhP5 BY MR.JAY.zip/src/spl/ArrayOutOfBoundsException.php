<?php
class ArrayOutOfBoundsException extends OutOfBoundsException{

}