<?php
abstract class ThreadedLogger extends \Thread implements Logger{

}