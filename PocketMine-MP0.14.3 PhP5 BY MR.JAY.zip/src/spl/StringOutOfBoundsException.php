<?php
class StringOutOfBoundsException extends OutOfBoundsException{

}