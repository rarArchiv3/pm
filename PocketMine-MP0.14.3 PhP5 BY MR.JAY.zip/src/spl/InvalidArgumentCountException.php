<?php
class InvalidArgumentCountException extends InvalidArgumentException{

}