<?php
class UndefinedVariableException extends InvalidStateException{

}