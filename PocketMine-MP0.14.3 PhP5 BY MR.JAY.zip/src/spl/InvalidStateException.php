<?php
class InvalidStateException extends InvalidArgumentException{

}