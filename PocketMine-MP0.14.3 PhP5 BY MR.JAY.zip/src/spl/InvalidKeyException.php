<?php
class InvalidKeyException extends InvalidArgumentException{

}